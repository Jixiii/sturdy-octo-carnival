# minesweeper_java
扫雷游戏（java版）

--利用swing做出的扫雷桌面游戏，运行时直接双击可执行文件夹下的“扫雷.exe”即可
